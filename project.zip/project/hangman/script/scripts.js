document.addEventListener('DOMContentLoaded', () => {
    const words = [
        { word: "BUTTERFLY", hint: "an insect" },
        { word: "BRAZIL", hint: "a country" },
        { word: "UMBRELLA", hint: "used to protect against rain" },
        { word: "PINEAPPLE", hint: "a tropical fruit with spiky skin" },
        { word: "FIREWORKS", hint: "used for celebrations and events" },
        { word: "SUNGLASSES", hint: "worn to protect the eyes from the sun" },
        { word: "SNOWFLAKE", hint: "a unique ice crystal" },
        { word: "BRAZIL", hint: "a country" },
        { word: "ELEPHANT", hint: "a large mammal with tusks" },
        { word: "GUITAR", hint: "a musical instrument" },
        { word: "TELESCOPE", hint: "used for viewing distant objects" },
        { word: "BACKPACK", hint: "carried on the back for holding belongings" },
        { word: "CAMERA", hint: "captures still photographs or video" },
        { word: "WATERMELON", hint: "a juicy, sweet fruit with green skin" },
        { word: "SWIMMING", hint: "activity done in water for recreation or sport" }
    ];

    let currentWordIndex = Math.floor(Math.random() * words.length);
    let currentWord = words[currentWordIndex].word;
    let currentHint = words[currentWordIndex].hint;
    let displayedWord = '_ '.repeat(currentWord.length).trim();
    let incorrectGuesses = 0;

    const wordContainer = document.getElementById('wordContainer');
    const hintContainer = document.getElementById('hint');
    const incorrectGuessesContainer = document.getElementById('incorrectGuesses');
    const feedbackImage = document.getElementById('feedback');
    const playAgainButton = document.getElementById('playAgain');

    const correctSound = document.getElementById('correctSound');
    const incorrectSound = document.getElementById('incorrectSound');
    const winSound = document.getElementById('winSound');
    const loseSound = document.getElementById('loseSound');

    wordContainer.textContent = displayedWord;
    hintContainer.textContent = currentHint;

    document.querySelectorAll('.key').forEach(button => {
        button.addEventListener('click', () => {
            const letter = button.textContent;
            if (currentWord.includes(letter)) {
                updateDisplayedWord(letter);
                correctSound.play();
                feedbackImage.src = "images/1.jpg";
                feedbackImage.style.display = "block";
            } else {
                incorrectGuesses++;
                incorrectGuessesContainer.textContent = `${incorrectGuesses}/7`;
                incorrectSound.play();
                feedbackImage.src = "images/2.jpg";
                feedbackImage.style.display = "block";
                if (incorrectGuesses >= 7) {
                    loseSound.play();
                    feedbackImage.src = "images/4.png";
                    feedbackImage.style.display = "block";
                    alert('Game Over!');
                    playAgainButton.style.display = "block";
                    document.querySelectorAll('.key').forEach(button => button.disabled = true);
                }
            }
            button.disabled = true;
        });
    });

    function updateDisplayedWord(letter) {
        let newDisplayedWord = '';
        for (let i = 0; i < currentWord.length; i++) {
            if (currentWord[i] === letter) {
                newDisplayedWord += letter + ' ';
            } else {
                newDisplayedWord += displayedWord[i * 2] + ' ';
            }
        }
        displayedWord = newDisplayedWord.trim();
        wordContainer.textContent = displayedWord;

        if (!displayedWord.includes('_')) {
            winSound.play();
            feedbackImage.src = "images/3.jpg";
            feedbackImage.style.display = "block";
            alert('You Win!');
            playAgainButton.style.display = "block";
            document.querySelectorAll('.key').forEach(button => button.disabled = true);
        }
    }

    window.resetGame = function() {
        currentWordIndex = Math.floor(Math.random() * words.length);
        currentWord = words[currentWordIndex].word;
        currentHint = words[currentWordIndex].hint;
        displayedWord = '_ '.repeat(currentWord.length).trim();
        incorrectGuesses = 0;

        wordContainer.textContent = displayedWord;
        hintContainer.textContent = currentHint;
        incorrectGuessesContainer.textContent = `0/7`;
        feedbackImage.style.display = "none";
        playAgainButton.style.display = "none";

        document.querySelectorAll('.key').forEach(button => {
            button.disabled = false;
        });
    }
});
