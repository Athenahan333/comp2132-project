class DiceGame {
    constructor() {
        this.playerScore = 0;
        this.opponentScore = 0;
        this.roundsLeft = 3;
        this.initializeElements();
        this.addEventListeners();
    }

    initializeElements() {
        this.playerDice1 = document.getElementById('playerDice1');
        this.playerDice2 = document.getElementById('playerDice2');
        this.opponentDice1 = document.getElementById('opponentDice1');
        this.opponentDice2 = document.getElementById('opponentDice2');
        this.playerRoundScore = document.getElementById('playerRoundScore');
        this.playerTotalScore = document.getElementById('playerTotalScore');
        this.opponentRoundScore = document.getElementById('opponentRoundScore');
        this.opponentTotalScore = document.getElementById('opponentTotalScore');
        this.rollDiceBtn = document.getElementById('rollDiceBtn');
        this.newGameBtn = document.getElementById('newGameBtn');
    }

    addEventListeners() {
        this.rollDiceBtn.addEventListener('click', () => this.rollDice());
        this.newGameBtn.addEventListener('click', () => this.resetGame());
    }

    

    rollDice() {
        if (this.roundsLeft > 0) {
            const playerRoll1 = this.roll();
            const playerRoll2 = this.roll();
            const opponentRoll1 = this.roll();
            const opponentRoll2 = this.roll();

            this.playerDice1.src = `dice_image/dice${playerRoll1}0.png`;
            this.playerDice2.src = `dice_image/dice${playerRoll2}0.png`;
            this.opponentDice1.src = `dice_image/dice0${opponentRoll1}.png`;
            this.opponentDice2.src = `dice_image/dice0${opponentRoll2}.png`;

            const playerRoundScore = this.calculateScore(playerRoll1, playerRoll2);
            const opponentRoundScore = this.calculateScore(opponentRoll1, opponentRoll2);

            this.playerScore += playerRoundScore;
            this.opponentScore += opponentRoundScore;

            this.playerRoundScore.textContent = `Score this Round: ${playerRoundScore}`;
            this.playerTotalScore.textContent = `Total Score: ${this.playerScore}`;
            this.opponentRoundScore.textContent = `Score this Round: ${opponentRoundScore}`;
            this.opponentTotalScore.textContent = `Total Score: ${this.opponentScore}`;

            this.roundsLeft--;

            if (this.roundsLeft === 0) {
                this.displayWinner();
            }
        }
    }

    calculateScore(die1, die2) {
        if (die1 === 1 && die2 === 1) {
            return (die1 + die2 + 12) * 2;
        } else if (die1 === 1 || die2 === 1) {
            return 0;
        }else if (die1 === die2) {
            return (die1 + die2) * 2;
        } else {
            return die1 + die2;
        }
    }

    roll() {
        return Math.floor(Math.random() * 6) + 1;
    }

    displayWinner() {
        if (this.playerScore > this.opponentScore) {
            alert('Player Wins!');
        } else if (this.playerScore < this.opponentScore) {
            alert('Opponent Wins!');
        } else {
            alert('It\'s a Tie!');
        }
    }

    resetGame() {
        this.playerScore = 0;
        this.opponentScore = 0;
        this.roundsLeft = 3;
        this.playerDice1.src = 'dice_image/images1.png';
        this.playerDice2.src = 'dice_image/images1.png';
        this.opponentDice1.src = 'dice_image/images2.png';
        this.opponentDice2.src = 'dice_image/images2.png';
        this.playerRoundScore.textContent = 'Score this Round: 0';
        this.playerTotalScore.textContent = 'Total Score: 0';
        this.opponentRoundScore.textContent = 'Score this Round: 0';
        this.opponentTotalScore.textContent = 'Total Score: 0';
    }
}




document.addEventListener('DOMContentLoaded', () => new DiceGame());


